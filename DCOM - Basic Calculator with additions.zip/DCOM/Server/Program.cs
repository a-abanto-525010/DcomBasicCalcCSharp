﻿using Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public interface IMathOperations
    {
        double Addition(double a, double b); 
        double Subtraction(double a, double b); 
        double Multiplication(double a, double b); 
        double Division(double a, double b);
        double Modulus(double a, double b);
        void exitFlag();
    }

    public class MathOperations : MarshalByRefObject, IMathOperations
    {
        private static bool serverExit = false;
        public static bool EndServer
        {
            get { return serverExit; }
        }
        public double Addition(double a, double b)
        {
            return a + b;
        }
        public double Subtraction(double a, double b)
        {
            return a - b;
        }
        public double Multiplication(double a, double b)
        {
            return a * b;
        }
        public double Division(double a, double b)
        {
            return a / b;
        }
        public double Modulus(double a, double b)
        {
            return a % b;
        }
        public  void exitFlag()
        {
            serverExit = true;
        }
    }
}
    public class Program
    {
        static void Main(string[] args)
        {
            var channel = new TcpChannel(8080);
            ChannelServices.RegisterChannel(channel, false);

            RemotingConfiguration.RegisterWellKnownServiceType(
                typeof(MathOperations), "MathOperations", WellKnownObjectMode.Singleton);

            Console.WriteLine("Server started...");
        while (!MathOperations.EndServer)
        { 
            System.Threading.Thread.Sleep(1000);
        }

        Console.WriteLine("Shutting down...");
    }
    }

