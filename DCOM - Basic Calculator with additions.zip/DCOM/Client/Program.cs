﻿using Server;
using System;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var channel = new TcpChannel();
            ChannelServices.RegisterChannel(channel, false);

            IMathOperations remoteObj = (IMathOperations)Activator.GetObject(
                typeof(IMathOperations), "tcp://localhost:8080/MathOperations");
            Console.WriteLine("BASIC CALCULATOR \nType 'exit' to exit the app.");
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter value 1: ");
                    string input1 = Console.ReadLine();

                    if (justExitThisApp(input1))
                    {
                        Console.WriteLine("Program will now exit...");
                        remoteObj.exitFlag();
                        Environment.Exit(0);
                    }

                    double value1 = Convert.ToDouble(input1);

                    Console.WriteLine("Enter value 2: ");
                    string input2 = Console.ReadLine();

                    if (justExitThisApp(input2))
                    {
                        Console.WriteLine("Program will now exit...");
                        remoteObj.exitFlag();
                        Environment.Exit(0);
                    }

                    double value2 = Convert.ToDouble(input2);

                    Console.WriteLine("Select Operation \n" +
                                      "\n 1. Add" +
                                      "\n 2. Subtract" +
                                      "\n 3. Multiply" +
                                      "\n 4. Divide" +
                                      "\n 5. Modulus" +
                                      "\n 6. Exit");

                    if (int.TryParse(Console.ReadLine(), out int choice) && choice >= 1 && choice <= 6)
                    {
                        switch (choice)
                        {
                            case 1:
                                Console.WriteLine("Result: " + remoteObj.Addition(value1, value2));
                                break;
                            case 2:
                                Console.WriteLine("Result: " + remoteObj.Subtraction(value1, value2));
                                break;
                            case 3:
                                Console.WriteLine("Result: " + remoteObj.Multiplication(value1, value2));
                                break;
                            case 4:
                                Console.WriteLine("Result: " + remoteObj.Division(value1, value2));
                                break;
                            case 5:
                                Console.WriteLine("Result: " + remoteObj.Modulus(value1, value2));
                                break;
                            case 6:
                                Console.WriteLine("Program will now exit...");
                                remoteObj.exitFlag();
                                Environment.Exit(0);
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice. Please try again.");
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred: {ex.Message}");
                }
                finally
                {
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }

        private static bool justExitThisApp(string input)
        {
            return string.Equals(input, "exit", StringComparison.OrdinalIgnoreCase);
        }
    }
}